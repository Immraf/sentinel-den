# Basic SIEM and Log Monitoring Lab

A reproducible, **isolated** VirtualBox laboratory that collects system, authentication
and web-server logs into a single-node SIEM, detects six controlled security scenarios,
and produces analyst-grade evidence.

> Defensive project. Everything runs on a host-only network. No public IP is ever
> scanned, no real credentials are used, no malware or destructive exploitation.

## 1. Architecture

```text
  analyst-01 (Kali Linux 2024.2)      192.168.56.30
        |   Nmap / Wireshark / OWASP ZAP
        |
        |   vboxnet0 - Host-Only, isolated, 192.168.56.0/24
        |
  target-01  (Debian 12)              192.168.56.20
        |   OpenSSH 22, Apache2 80, DVWA (local), Wazuh agent
        |   agent -> 1514/tcp, syslog -> 514/udp
        |
  siem-01    (Ubuntu Server 22.04)    192.168.56.10
            Wazuh manager + indexer + dashboard (443/tcp)
```

| VM | OS | Hostname | IP | Role | Key services |
|---|---|---|---|---|---|
| SIEM | Ubuntu 22.04 LTS | siem-01 | 192.168.56.10 | Monitoring | wazuh-manager, wazuh-indexer, dashboard, rsyslog |
| Target | Debian 12 | target-01 | 192.168.56.20 | Monitored asset | sshd, apache2, DVWA, wazuh-agent |
| Analyst | Kali 2024.2 | analyst-01 | 192.168.56.30 | Authorized testing | nmap, wireshark, zaproxy |

## 2. Prerequisites

- VirtualBox 7.x, 12 GB RAM and 80 GB free disk on the host
- ISOs: Ubuntu Server 22.04, Debian 12 netinst, Kali Linux
- Disable the NAT adapter after installation to keep the lab offline

## 3. VirtualBox network configuration

1. File > Tools > Network Manager > create host-only network `vboxnet0`,
   address `192.168.56.1/24`, **DHCP disabled**.
2. Each VM: Settings > Network > Adapter 1 = Host-Only Adapter (`vboxnet0`).
3. Adapter 2 (NAT) may be enabled temporarily for package installation, then
   **disabled** before any testing begins.

Static addressing example (`/etc/netplan/01-lab.yaml`):

```yaml
network:
  version: 2
  ethernets:
    enp0s8:
      addresses: [192.168.56.10/24]
```

## 4. SIEM installation (siem-01)

```bash
curl -sO https://packages.wazuh.com/4.7/wazuh-install.sh
sudo bash ./wazuh-install.sh -a          # all-in-one single node
sudo tar -xf wazuh-install-files.tar     # generated admin credentials
sudo cp detections/local_rules.xml /var/ossec/etc/rules/local_rules.xml
sudo systemctl restart wazuh-manager
```

## 5. Log collection (target-01)

```bash
sudo WAZUH_MANAGER='192.168.56.10' dpkg -i ./wazuh-agent_4.7.0-1_amd64.deb
sudo cp configuration/agent-ossec.conf /var/ossec/etc/ossec.conf   # review first
sudo systemctl enable --now wazuh-agent
sudo bash configuration/ufw_baseline.sh
```

Collected sources: `auth.log` (SSH, sudo), `syslog`, journald service events,
`ufw.log` kernel firewall drops, Apache `access.log`/`error.log`, and file-integrity
monitoring of `/etc` and `/var/www/html`.

## 6. Detection rules

See `detections/README.md`. Rules 100201-100601 map one-to-one to scenarios S1-S6
and carry MITRE ATT&CK technique references.

## 7. Safe test procedures

```bash
./scripts/00_validate_lab.sh        # connectivity, services, ingest, NTP
sudo ./scripts/11_wireshark_capture.sh 120 &   # capture lab traffic first
./scripts/10_generate_events.sh     # scenarios S1-S6
./scripts/12_zap_scan.sh            # ZAP baseline, local app only
./scripts/20_collect_evidence.sh    # bundle logs + alerts (redacted)
```

Every script sources `lab.conf` and refuses to run against non-RFC1918 addresses.

## 8. Scenarios

| ID | Scenario | Command | Detection |
|---|---|---|---|
| S1 | Failed SSH authentication | 5 bad-password SSH attempts | rule 100201 |
| S2 | Successful SSH login | key-based login as labuser | rule 100202 |
| S3 | Network reconnaissance | `nmap -sS -sV --top-ports 100` | rule 100301 + pcap |
| S4 | Web application requests | curl + ZAP baseline | rules 100401/100402 |
| S5 | Privileged activity | `sudo tail /var/log/auth.log` | rule 100501 |
| S6 | Service activity | `systemctl restart apache2` | rule 100601 |

## 9. Evidence collection

```text
evidence/
  architecture/  vm-configuration/  network/  siem/  logs/
  nmap/  wireshark/  zap/  detections/  remediation/  screenshots/
```

Naming convention: `01_virtualbox_lab_topology.png`, `02_siem_dashboard.png`,
`03_failed_ssh_detection.png`, `04_successful_ssh_login.png`, `05_nmap_lab_scan.png`,
`06_wireshark_tcp_capture.png`, `07_zap_local_app_assessment.png`,
`08_privileged_activity_detection.png`, `09_security_events_timeline.png`.

Each screenshot must show the VM/hostname, a visible timestamp, and the command or
query used. Never capture passwords, keys or tokens.

## 10. Troubleshooting

| Symptom | Check |
|---|---|
| Agent shows "never connected" | `ufw allow from 192.168.56.0/24 to any port 1514` on siem-01 |
| No Apache events | agent `ossec.conf` localfile paths; `ls -l /var/log/apache2` permissions |
| Timestamps misaligned | `timedatectl set-ntp true` on every VM, same timezone (UTC) |
| Dashboard unreachable | `systemctl status wazuh-dashboard`; browse `https://192.168.56.10` |
| Rule never fires | replay a sample line through `/var/ossec/bin/wazuh-logtest` |

## 11. Cleanup / reset

```bash
./scripts/99_reset.sh     # rotate logs, truncate alerts
```

Full reset: restore each VM to the "clean-baseline" VirtualBox snapshot taken before
the first scenario run. Delete `evidence/bundle_*` before sharing the package.

## 12. Ethics and scope

In scope: the three lab VMs on 192.168.56.0/24 owned by the author.
Out of scope: any public IP, third-party website, real user account, credential
attacks outside the lab, malware, and destructive exploitation. The deliberately
vulnerable web application must never be exposed beyond the host-only network.
