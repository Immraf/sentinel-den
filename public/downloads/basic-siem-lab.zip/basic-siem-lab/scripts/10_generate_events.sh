#!/usr/bin/env bash
# Generate the six controlled detection scenarios against the LAB TARGET ONLY.
# Reproducible, non-destructive, no real credentials.
set -uo pipefail
source "$(dirname "$0")/../lab.conf"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
OUT="${EVIDENCE_DIR}/detections/run_${STAMP}.log"
mkdir -p "$(dirname "$OUT")"
log(){ printf '[%s] %s\n' "$(date -u +%FT%TZ)" "$1" | tee -a "$OUT"; }

case "$TARGET_IP" in
  10.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*) ;;
  *) echo "TARGET_IP is not RFC1918 - refusing to run"; exit 2 ;;
esac

log "S1 failed SSH authentication x5 (bogus passwords, lab account only)"
for i in $(seq 1 5); do
  sshpass -p "wrong-pw-$i" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 \
    -o PreferredAuthentications=password "${TARGET_USER}@${TARGET_IP}" true \
    2>>"$OUT" || true
done

log "S2 successful SSH login (interactive skipped in CI: uses key auth)"
ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 \
  "${TARGET_USER}@${TARGET_IP}" "echo lab-login-ok; id" 2>>"$OUT" || true

log "S3 controlled Nmap scan against target only"
nmap -Pn -sS -sV --top-ports 100 --host-timeout 60s "$TARGET_IP" \
  -oN "${EVIDENCE_DIR}/nmap/scan_${STAMP}.txt" >>"$OUT" 2>&1 || true

log "S4 web requests (curl - see 12_zap_scan.sh for authorized ZAP passive scan)"
for path in / /index.html "$WEB_APP_PATH" "$WEB_APP_PATH/login.php" /.git/config /admin; do
  curl -s -o /dev/null -w "  %{http_code} %{url_effective}\n" \
    -A "Lab-Scenario-Runner" "http://${TARGET_IP}${path}" | tee -a "$OUT"
done

log "S5 privileged activity (sudo) on target"
ssh -o StrictHostKeyChecking=no "${TARGET_USER}@${TARGET_IP}" \
  "sudo -n /usr/bin/id; sudo -n /usr/bin/tail -n 1 /var/log/auth.log" \
  2>>"$OUT" || true

log "S6 service activity (restart apache2)"
ssh -o StrictHostKeyChecking=no "${TARGET_USER}@${TARGET_IP}" \
  "sudo -n systemctl restart apache2 && systemctl is-active apache2" \
  2>>"$OUT" || true

log "Done. Evidence: $OUT"
