#!/usr/bin/env bash
# Reset the lab to a clean baseline: clear alerts, rotate logs. NON-DESTRUCTIVE to VM state.
set -uo pipefail
source "$(dirname "$0")/../lab.conf"
read -rp "Rotate SIEM alerts and target logs? [y/N] " a; [[ "$a" == "y" ]] || exit 0
sudo logrotate -f /etc/logrotate.conf 2>/dev/null || true
if [ -f /var/ossec/logs/alerts/alerts.json ]; then
  sudo truncate -s 0 /var/ossec/logs/alerts/alerts.json
fi
ssh -o StrictHostKeyChecking=no "${TARGET_USER}@${TARGET_IP}" \
  "sudo logrotate -f /etc/logrotate.conf" || true
echo "Reset complete."
