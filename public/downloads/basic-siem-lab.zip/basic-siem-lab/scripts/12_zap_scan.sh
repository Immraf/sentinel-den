#!/usr/bin/env bash
# OWASP ZAP baseline scan against the LOCAL lab web app only.
set -uo pipefail
source "$(dirname "$0")/../lab.conf"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
OUT_DIR="${EVIDENCE_DIR}/zap"
mkdir -p "$OUT_DIR"

TARGET_URL="http://${TARGET_IP}${WEB_APP_PATH}/"
case "$TARGET_IP" in
  10.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*) ;;
  *) echo "Refusing to scan non-private target"; exit 2 ;;
esac

echo "ZAP baseline against $TARGET_URL"
if command -v zap-baseline.py >/dev/null 2>&1; then
  zap-baseline.py -t "$TARGET_URL" -r "zap_${STAMP}.html" -x "zap_${STAMP}.xml" || true
  mv zap_${STAMP}.* "$OUT_DIR/" 2>/dev/null || true
else
  docker run --rm -v "$OUT_DIR:/zap/wrk" -t ghcr.io/zaproxy/zaproxy:stable \
    zap-baseline.py -t "$TARGET_URL" -r "zap_${STAMP}.html" -x "zap_${STAMP}.xml" || true
fi
echo "Report: $OUT_DIR/zap_${STAMP}.html"
