#!/usr/bin/env bash
# Capture lab traffic on the isolated interface for a fixed duration.
# Never captures on external interfaces.
set -uo pipefail
source "$(dirname "$0")/../lab.conf"
DUR="${1:-60}"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
OUT="${EVIDENCE_DIR}/wireshark/lab_${STAMP}.pcap"
mkdir -p "$(dirname "$OUT")"

ip -o link show "$LAB_IFACE" >/dev/null 2>&1 || { echo "Interface $LAB_IFACE not found"; exit 2; }

echo "Capturing ${DUR}s on ${LAB_IFACE} restricted to ${LAB_NET} -> $OUT"
sudo tcpdump -i "$LAB_IFACE" -n -w "$OUT" -G "$DUR" -W 1 "net $LAB_NET"
echo "Open with: wireshark $OUT"
