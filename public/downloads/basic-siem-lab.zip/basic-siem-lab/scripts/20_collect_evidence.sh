#!/usr/bin/env bash
# Collect evidence bundle (logs, configs, alerts). Redacts obvious secrets.
set -uo pipefail
source "$(dirname "$0")/../lab.conf"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
DEST="${EVIDENCE_DIR}/bundle_${STAMP}"
mkdir -p "$DEST"/{siem,logs,vm-configuration}

echo "Collecting SIEM alerts (last 24h)"
if [ -r /var/ossec/logs/alerts/alerts.json ]; then
  tail -n 5000 /var/ossec/logs/alerts/alerts.json > "$DEST/siem/alerts.json"
fi

echo "Collecting target logs via ssh"
ssh -o StrictHostKeyChecking=no "${TARGET_USER}@${TARGET_IP}" \
  "sudo tail -n 2000 /var/log/auth.log /var/log/apache2/access.log /var/log/apache2/error.log 2>/dev/null" \
  > "$DEST/logs/target_tail.log" || true

echo "Sanitizing"
sed -Ei 's/(password|token|secret|api[_-]?key)=[^ ]+/\1=REDACTED/gi' "$DEST/logs/target_tail.log" || true

tar -C "$(dirname "$DEST")" -czf "${DEST}.tgz" "$(basename "$DEST")"
echo "Bundle: ${DEST}.tgz"
