#!/usr/bin/env bash
# Validate the isolated lab: addressing, connectivity, services, SIEM ingest.
# Read-only and idempotent - safe to run repeatedly.
set -uo pipefail
source "$(dirname "$0")/../lab.conf"
RC=0
ok(){ printf '  [ OK ] %s\n' "$1"; }
bad(){ printf '  [FAIL] %s\n' "$1"; RC=1; }

echo "== Lab validation ($(date -u +%FT%TZ)) =="

echo "-- Safety guard: only RFC1918 lab addresses are allowed"
for ip in "$SIEM_IP" "$TARGET_IP" "$ANALYST_IP"; do
  case "$ip" in
    10.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*) ok "$ip is private" ;;
    *) bad "$ip is NOT RFC1918 - aborting"; exit 2 ;;
  esac
done

echo "-- Reachability"
for ip in "$SIEM_IP" "$TARGET_IP"; do
  ping -c1 -W2 "$ip" >/dev/null 2>&1 && ok "ping $ip" || bad "ping $ip"
done

echo "-- Target services"
for port in 22 80; do
  timeout 3 bash -c "echo > /dev/tcp/$TARGET_IP/$port" 2>/dev/null \
    && ok "tcp/$port open on target" || bad "tcp/$port closed on target"
done

echo "-- SIEM dashboard"
curl -sk --max-time 5 "https://$SIEM_IP" >/dev/null \
  && ok "SIEM dashboard responds" || bad "SIEM dashboard unreachable"

echo "-- Agent registration (run on siem-01)"
if command -v /var/ossec/bin/agent_control >/dev/null 2>&1; then
  /var/ossec/bin/agent_control -lc | grep -q "$TARGET_IP" \
    && ok "target agent is active" || bad "target agent not active"
else
  echo "  [SKIP] not on the SIEM host"
fi

echo "-- Time sync (log correlation depends on it)"
timedatectl show -p NTPSynchronized --value 2>/dev/null | grep -q yes \
  && ok "NTP synchronized" || bad "NTP not synchronized"

echo "== Result: $([ $RC -eq 0 ] && echo PASS || echo ATTENTION REQUIRED) =="
exit $RC
