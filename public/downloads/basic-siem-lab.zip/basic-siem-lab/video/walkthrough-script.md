# Security Walkthrough Video Script (2:50)

| Time | Screen | Narration |
|---|---|---|
| 0:00-0:20 | VirtualBox manager + topology diagram | "Three VMs on an isolated host-only network, 192.168.56.0/24: a Kali analyst box, a Debian target running SSH and Apache, and an Ubuntu SIEM. Nothing here touches the internet." |
| 0:20-0:50 | Wazuh dashboard overview | "Before this project there was no monitoring. Now every authentication, sudo call, service change, firewall drop and HTTP request from the target arrives here within seconds." |
| 0:50-1:20 | Terminal on analyst-01 running `./scripts/10_generate_events.sh` | "I run five failed SSH logins with bogus passwords against the lab account, then a legitimate key-based login." |
| 1:20-1:50 | Dashboard filtered `rule.id:100201` then `100202` | "Rule 100201 aggregates the five failures into one brute-force alert with the source IP; rule 100202 shows the successful login, user and source." |
| 1:50-2:20 | Nmap output, Wireshark pcap, ZAP report | "A controlled Nmap scan of the target only; Wireshark on the lab interface showing the SYN sweep and the TCP handshake; a ZAP baseline scan of the local vulnerable app - missing security headers, no third-party site touched." |
| 2:20-2:50 | Findings and remediation table | "Four findings: password SSH with root login, an over-exposed vulnerable app, missing security headers and no retention policy. Fixes are prioritized - key-only SSH first, then default-deny firewall and alert thresholds." |
| 2:50-3:00 | Dashboard timeline | "Monitoring turns invisible activity into evidence. That is the whole point of continuous logging." |

Recording notes: 1920x1080, show a clock or `date -u` in each terminal, never show
passwords or the Wazuh admin credentials, save as `video/walkthrough.mp4`.
