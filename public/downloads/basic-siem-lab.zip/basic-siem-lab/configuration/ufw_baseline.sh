#!/usr/bin/env bash
# Host firewall baseline for target-01: default deny, lab-only allow, log drops.
set -euo pipefail
source "$(dirname "$0")/../lab.conf"
sudo ufw --force reset
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow from "$LAB_NET" to any port 22 proto tcp comment 'lab ssh'
sudo ufw allow from "$LAB_NET" to any port 80 proto tcp comment 'lab http'
sudo ufw logging medium
sudo ufw --force enable
sudo ufw status verbose
