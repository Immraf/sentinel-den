# Detection rules and verification queries

| Rule | Scenario | Trigger | Level | Verification query (Wazuh Dashboard / OpenSearch DQL) |
|---|---|---|---|---|
| 100201 | S1 failed SSH | 5 sshd failures from one IP in 60s | 10 | `rule.id:100201 and data.srcip:"192.168.56.30"` |
| 100202 | S2 successful SSH | Accepted password/publickey | 5 | `rule.id:100202 and data.dstuser:"labuser"` |
| 100301 | S3 recon | 20 firewall blocks from one IP in 30s | 8 | `rule.id:100301` |
| 100401 | S4 web scan | 15 HTTP 4xx from one IP in 60s | 7 | `rule.id:100401 and data.id:4*` |
| 100402 | S4 sensitive path | Request to /.git, /admin, .env | 6 | `rule.id:100402` |
| 100501 | S5 privileged | sudo touching /etc/shadow or sudoers | 10 | `rule.id:100501 and data.srcuser:*` |
| 100601 | S6 service | systemd unit state change | 5 | `rule.id:100601` |

## Verifying a rule without waiting for a real event

```bash
# On siem-01 - replay a sample line through the analysis engine
/var/ossec/bin/wazuh-logtest
# then paste:
# Aug 11 09:14:02 target-01 sshd[1421]: Failed password for root from 192.168.56.30 port 51244 ssh2
```

`wazuh-logtest` prints the matched decoder, rule id and level. A rule is considered
verified only when both `wazuh-logtest` matches it and a live scenario run produces
the alert in the dashboard.
